package com.example.myapplication;

import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.databinding.ActivityTrackerBinding;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class TrackerActivity extends AppCompatActivity {

    Button b1,b2;
    RecyclerView rv1;
    MaterialCardView materialCardView, materialCardView1, materialCardView2;
    CircularProgressIndicator circularProgressIndicator;
    LinearProgressIndicator lp1, lp2, lp3;
    TextView t1, t2, textp, textf, textc, txtcal2, textp2, textf2, textc2;
    String updateCal;
    int intcal, gpro, gfat, gcarb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);

        List<String> items = new LinkedList<>();
        rv1 = findViewById(R.id.Rv1);
        rv1.setLayoutManager(new LinearLayoutManager(this));
        DemoAdapter adapter = new DemoAdapter(items);
        rv1.setAdapter(adapter);


        SharedPreferences sharedPreferences1 = getSharedPreferences("NutritionData", MODE_PRIVATE);
        double calories = sharedPreferences1.getFloat("calories", 0.0f);
        double proteins = sharedPreferences1.getFloat("proteins", 0.0f);
        double fats = sharedPreferences1.getFloat("fats", 0.0f);
        double carbs = sharedPreferences1.getFloat("carbs", 0.0f);
        double totalCalories = sharedPreferences1.getFloat("totalCalories", 0.0f);
        double totalproteins = sharedPreferences1.getFloat("totalproteins", 0.0f);
        double totalfats = sharedPreferences1.getFloat("totalfats", 0.0f);
        double totalcarbs = sharedPreferences1.getFloat("totalcarbs", 0.0f);
        String query = sharedPreferences1.getString("query", "");



        b1 = findViewById(R.id.addbreakfast);
        t2 = findViewById(R.id.t2);
        t1 = findViewById(R.id.t1);
        circularProgressIndicator = findViewById(R.id.circularProgressIndicator);
        lp1 = findViewById(R.id.lp1);
        lp2 = findViewById(R.id.lp2);
        lp3 = findViewById(R.id.lp3);
        textp = findViewById(R.id.txtprotein);
        textf = findViewById(R.id.txtfats);
        textc = findViewById(R.id.textcarbs);
        txtcal2 = findViewById(R.id.txtcal2);
        b2 = findViewById(R.id.btnclear);
        textp2 = findViewById(R.id.txtprotein2);
        textf2 = findViewById(R.id.txtfats2);
        textc2 = findViewById(R.id.textcarbs2);


        items.add(query);
        adapter.notifyDataSetChanged();

        SharedPreferences sharedPreferences = getSharedPreferences("Infos", MODE_PRIVATE);
        updateCal = sharedPreferences.getString("Cal", "");
        t2.setText("of " + updateCal + " kcal");
        txtcal2.setText(String.valueOf(calories));
        intcal = ((int) Integer.parseInt(updateCal));
        t1.setText(Integer.toString((int) totalCalories));


        circularProgressIndicator.setMax(Integer.parseInt(updateCal));
        circularProgressIndicator.incrementProgressBy((int) calories);
        gpro = (int) (intcal * 0.20 / 4);
        gfat = (int) (intcal * 0.25 / 9);
        gcarb = (int) (intcal * 0.55 / 4);
        textp2.setText("/" + gpro);
        textf2.setText("/" + gfat);
        textc2.setText("/" + gcarb);
        textp.setText(Integer.toString((int) totalproteins));
        textf.setText(Integer.toString((int) totalfats));
        textc.setText(Integer.toString((int) totalcarbs));


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TrackerActivity.this, NinjaActivity.class);
                startActivity(intent);
                finish();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences1 = getSharedPreferences("NutritionData", MODE_PRIVATE);
                double totalCalories = sharedPreferences1.getFloat("totalCalories", 0.0f);
                double totalproteins = sharedPreferences1.getFloat("totalproteins", 0.0f);
                double totalfats = sharedPreferences1.getFloat("totalfats", 0.0f);
                double totalcarbs = sharedPreferences1.getFloat("totalcarbs", 0.0f);

                totalCalories = 0;
                totalproteins = 0;
                totalfats = 0 ;
                totalcarbs =0;
                SharedPreferences.Editor editor = sharedPreferences1.edit();

                editor.putFloat("totalCalories", (float) totalCalories);
                editor.putFloat("totalproteins",(float) totalproteins);
                editor.putFloat("totalfats",(float) totalfats);
                editor.putFloat("totalcarbs",(float) totalcarbs);
                editor.apply();
                textp.setText(Integer.toString((int) totalproteins));
                textf.setText(Integer.toString((int) totalfats));
                textc.setText(Integer.toString((int) totalcarbs));
                t1.setText(Integer.toString((int) totalCalories));
                circularProgressIndicator.setProgress(0);
            }
        });


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_tracker);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.bottom_home:
                    startActivity(new Intent(getApplicationContext(), SecondActivity.class));
                    finish();
                    return true;
                case R.id.bottom_tracker:
                    return true;
                case R.id.bottom_exercise:
                    startActivity(new Intent(getApplicationContext(), ExerciseActivity.class));
                    finish();
                    return true;
                case R.id.bottom_recipes:
                    startActivity(new Intent(getApplicationContext(), RecipeActivity.class));
                    finish();
                    return true;
            }
            return false;
        });

    }
}


