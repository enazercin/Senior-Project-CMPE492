package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SecondActivity extends AppCompatActivity {

    GoogleSignInOptions gso;
    GoogleSignInClient gsc;
    TextView name,email,textHupdate,textWupdate,textGupdate,textAUpdate,textBMIupdate,textSupdate,textWaterUpdate,textCalUpdate;
    Button signOutBtn;
    ImageView imageBMI,imageWater;
    String UpdateWeight,UpdateHeight,UpdateGender,UpdateAge,UpdateBMI,UpdateWater,UpdateCal;
    float intHeight,intWeight,intbmi,intWater,intAge,intHeightM;
    int intCal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);



        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        signOutBtn = findViewById(R.id.signOutBtn);
        imageBMI = findViewById(R.id.imageBMI);
        textWupdate=findViewById(R.id.textWupdate);
        textHupdate=findViewById(R.id.textHupdate);
        textGupdate=findViewById(R.id.textGupdate);
        textAUpdate=findViewById(R.id.textAUpdate);
        textBMIupdate=findViewById(R.id.textBMIupdate);
        textSupdate=findViewById(R.id.textSupdate);
        textWaterUpdate=findViewById(R.id.textWaterUpdate);
        textCalUpdate=findViewById(R.id.textCalUpdate);
        imageWater=findViewById(R.id.imageWater);

        intHeight = 170;
        intWeight = 85;
        intAge = 20;


        SharedPreferences sharedPreferences = getSharedPreferences("Infos",MODE_PRIVATE);
        UpdateWeight = sharedPreferences.getString("weight", "");
        UpdateHeight = sharedPreferences.getString("height", "");
        UpdateGender = sharedPreferences.getString("gender","");
        UpdateAge = sharedPreferences.getString("age","");
        textWupdate.setText(UpdateWeight + " kg");
        textHupdate.setText(UpdateHeight + " cm");
        textGupdate.setText(UpdateGender);
        textAUpdate.setText(UpdateAge);

        if (!UpdateHeight.isEmpty()) {
            intHeight = Float.parseFloat(UpdateHeight);
        }

        if (!UpdateWeight.isEmpty()) {
            intWeight = Float.parseFloat(UpdateWeight);
        }

        if (!UpdateAge.isEmpty()) {
            intAge = Float.parseFloat(UpdateAge);
        }
        intHeightM = intHeight/100;
        intbmi = intWeight/(intHeightM*intHeightM);
        UpdateBMI = Float.toString(intbmi);
        textBMIupdate.setText(UpdateBMI);
        if(intbmi<18.50){
            textSupdate.setText("Underweight");
        }
        else if (intbmi<25.00 && intbmi>18.50) {
            textSupdate.setText("Normal");
        }
        else if (intbmi<30.00 && intbmi>24.99) {
            textSupdate.setText("Overweight");
        }
        else{
            textSupdate.setText("Obese");
        }
        intWater = (float) (intWeight*0.033);
        UpdateWater = Float.toString(intWater);
        textWaterUpdate.setText(UpdateWater + " L");
        if (UpdateGender.equals("Male")){
            intCal = (int) (66.5 + (13.7 * intWeight) + (5 * intHeight) - (6.7 * intAge));
        }
        else {
            intCal = (int) (65.5 + (9.6 * intWeight) + (1.8 * intHeight) - (4.7 * intAge));
        }
        UpdateCal = Integer.toString(intCal);
        textCalUpdate.setText(UpdateCal + " cal");









        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().build();
        gsc = GoogleSignIn.getClient(this,gso);

        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
        if(acct!=null){
            String personName = acct.getDisplayName();
            String personEmail = acct.getEmail();
            name.setText(personName);
            email.setText(personEmail);
        }



        signOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signOut();
            }
        });

        imageBMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SecondActivity.this, BMIActivity.class);
                startActivity(intent);
                finish();

            }
        });

        imageWater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SecondActivity.this, ReminderActivity.class);
                startActivity(intent);
                finish();
            }
        });



        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_home);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.bottom_home:
                    return true;
                case R.id.bottom_tracker:
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("Cal",UpdateCal);
                    editor.apply();
                    startActivity(new Intent(getApplicationContext(), TrackerActivity.class));
                    finish();
                    return true;
                case R.id.bottom_exercise:
                    startActivity(new Intent(getApplicationContext(), ExerciseActivity.class));
                    finish();
                    return true;
                case R.id.bottom_recipes:
                    startActivity(new Intent(getApplicationContext(), RecipeActivity.class));
                    finish();
                    return true;
            }
            return false;
        });
    }

    void signOut(){
        gsc.signOut().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(Task<Void> task) {
                finish();
                startActivity(new Intent(SecondActivity.this,MainActivity.class));

            }
        });

    }
}