package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.LinkedList;
import java.util.List;

public class NinjaActivity extends AppCompatActivity implements ApiIntegrationUtil.ApiCallback {

    Button btn1, btn2;
    TextView data;
    EditText inputdata;
    String url;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ninja);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        data = findViewById(R.id.data1);
        inputdata = findViewById(R.id.edttxt1);




        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String query = inputdata.getText().toString();
                ApiIntegrationUtil.queryNutrition(query, NinjaActivity.this);
                Intent intent = new Intent(NinjaActivity.this, TrackerActivity.class);
                SharedPreferences sharedPreferences = getSharedPreferences("NutritionData", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("query", query);
                editor.apply();
                startActivity(intent);
                finish();

            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(NinjaActivity.this, TrackerActivity.class);
                startActivity(intent);
                finish();

            }
        });

    }



    @Override
    public void onResult(NutritonData nutritonData) {
        double calories = nutritonData.getCalories();
        double proteins = nutritonData.getProteins();
        double fats = nutritonData.getFats();
        double carbs = nutritonData.getCarbs();
        double totalCalories = nutritonData.getCalories();


        // Display data in TrackerActivity
        Intent intent = new Intent(NinjaActivity.this, TrackerActivity.class);
        SharedPreferences sharedPreferences = getSharedPreferences("NutritionData", MODE_PRIVATE);
        totalCalories = sharedPreferences.getFloat("totalCalories", 0.0f);
        double totalproteins = sharedPreferences.getFloat("totalproteins", 0.0f);
        double totalfats = sharedPreferences.getFloat("totalfats", 0.0f);
        double totalcarbs = sharedPreferences.getFloat("totalcarbs", 0.0f);
        totalCalories += calories;
        totalproteins += proteins;
        totalfats += fats;
        totalcarbs += carbs;
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putFloat("calories", (float) calories);
        editor.putFloat("proteins", (float) proteins);
        editor.putFloat("fats", (float) fats);
        editor.putFloat("carbs", (float) carbs);
        editor.putFloat("totalCalories", (float) totalCalories);
        editor.putFloat("totalproteins",(float) totalproteins);
        editor.putFloat("totalfats",(float) totalfats);
        editor.putFloat("totalcarbs",(float) totalcarbs);
        editor.apply();
        startActivity(intent);
        finish();
    }

    @Override
    public void onError(Exception e) {

    }
}

