package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class ReminderActivity extends AppCompatActivity {

    Button b1, b2, b3, b4, b5, b6, b7;
    long addSeconds;

    private static final String NOTIFICATION_TAG = "Nutrition Point";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);
        createNotificationChannel();

        SharedPreferences sharedPreferences = getSharedPreferences("SettingsData", Activity.MODE_PRIVATE);

        b1 = findViewById(R.id.min15Btn);
        b2 = findViewById(R.id.min30Btn);
        b3 = findViewById(R.id.h1Btn);
        b4 = findViewById(R.id.h2Btn);
        b5 = findViewById(R.id.h4Btn);
        b6 = findViewById(R.id.startBtn);
        b7 = findViewById(R.id.stopBtn);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b1.setTextColor(Color.parseColor("#000000"));
                b2.setTextColor(Color.WHITE);
                b3.setTextColor(Color.WHITE);
                b4.setTextColor(Color.WHITE);
                b5.setTextColor(Color.WHITE);
                addSeconds = 1000 * 60 * 15;
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b2.setTextColor(Color.parseColor("#000000"));
                b1.setTextColor(Color.WHITE);
                b3.setTextColor(Color.WHITE);
                b4.setTextColor(Color.WHITE);
                b5.setTextColor(Color.WHITE);
                addSeconds = 1000 * 60 * 30;
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b3.setTextColor(Color.parseColor("#000000"));
                b1.setTextColor(Color.WHITE);
                b2.setTextColor(Color.WHITE);
                b4.setTextColor(Color.WHITE);
                b5.setTextColor(Color.WHITE);
                addSeconds = 1000 * 60 * 60;
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b4.setTextColor(Color.parseColor("#000000"));
                b1.setTextColor(Color.WHITE);
                b3.setTextColor(Color.WHITE);
                b2.setTextColor(Color.WHITE);
                b5.setTextColor(Color.WHITE);
                addSeconds = 1000 * 60 * 120;
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                b5.setTextColor(Color.parseColor("#000000"));
                b1.setTextColor(Color.WHITE);
                b3.setTextColor(Color.WHITE);
                b4.setTextColor(Color.WHITE);
                b2.setTextColor(Color.WHITE);
                addSeconds = 1000 * 10;
            }
        });

        b6.setOnClickListener(v -> {
            Toast.makeText(this,"Reminder Set!",Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(ReminderActivity.this,ReminderBroadcast.class);
            @SuppressLint("UnspecifiedImmutableFlag") PendingIntent pendingIntent = PendingIntent.getBroadcast(ReminderActivity.this, 0, intent, 0);

            AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

            long timeAtButtonClick = System.currentTimeMillis();


            alarmManager.set(AlarmManager.RTC_WAKEUP,
                    timeAtButtonClick + addSeconds,
                    pendingIntent);

        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ReminderActivity.this, SecondActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    private void createNotificationChannel() {

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Health Diary";
            String description = "Water Reminder of Health Diary app";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("Water Reminder", name, importance);
            channel.setDescription(description);


            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }




    }




}
