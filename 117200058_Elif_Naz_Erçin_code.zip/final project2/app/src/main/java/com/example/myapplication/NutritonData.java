package com.example.myapplication;

public class NutritonData {
    private String itemName;
    private double calories;
    private double proteins;
    private double fats;
    private double carbs;
    private double totalcalories;

    public NutritonData(String itemName,double calories, double proteins, double fats, double carbs){
        this.itemName= itemName;
        this.calories=calories;
        this.proteins=proteins;
        this.fats=fats;
        this.carbs=carbs;
    }

    public double getCarbs() {
        return carbs;
    }

    public void setCarbs(double carbs) {
        this.carbs = carbs;
    }

    public double getFats() {
        return fats;
    }

    public void setFats(double fats) {
        this.fats = fats;
    }

    public double getProteins() {
        return proteins;
    }

    public void setProteins(double proteins) {
        this.proteins = proteins;
    }

    public double getCalories() {
        return calories;
    }

    public void setCalories(double calories) {
        this.calories = calories;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getTotalcalories() {
        return totalcalories;
    }

    public void setTotalcalories(double totalcalories) {
        this.totalcalories = totalcalories;
    }
}
