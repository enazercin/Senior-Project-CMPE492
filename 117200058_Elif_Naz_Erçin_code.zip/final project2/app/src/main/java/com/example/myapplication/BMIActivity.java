package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class BMIActivity extends AppCompatActivity {

    android.widget.Button calculatebmi;

    TextView currentweight, currentage ;
    TextView currentheight;
    ImageView increaseweight, decreaseweight, increaseage, decreaseage;
    SeekBar seekbarheight;
    RelativeLayout selectmale, selectfemale;

    int intweight = 75;
    int intage = 20;
    int currentprogress;
    String mintprogress = "170";
    String typeofuser="0";
    String weight2="55";
    String age2="20";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmiactivity);


        currentweight=findViewById(R.id.currentweight);
        currentage=findViewById(R.id.currentage);
        currentheight=findViewById(R.id.currentheight);
        increaseweight=findViewById(R.id.increaseweight);
        increaseage=findViewById(R.id.increaseage);
        decreaseweight=findViewById(R.id.decreaseweight);
        decreaseage=findViewById(R.id.decreaseage);
        seekbarheight=findViewById(R.id.seekbarheight);
        selectmale=findViewById(R.id.selectmale);
        selectfemale=findViewById(R.id.selectfemale);


        calculatebmi=findViewById(R.id.calculatebmi);


        selectmale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectmale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.bmibackgroundfocus));
                selectfemale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.bmibackground));
                typeofuser="Male";
            }
        });

        selectfemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectfemale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.bmibackgroundfocus));
                selectmale.setBackground(ContextCompat.getDrawable(getApplicationContext(),R.drawable.bmibackground));
                typeofuser="Female";
            }
        });

        seekbarheight.setMax(300);
        seekbarheight.setProgress(170);
        seekbarheight.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                currentprogress=i;
                mintprogress=String.valueOf(currentprogress);
                currentheight.setText(mintprogress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        increaseage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intage=intage+1;
                age2=String.valueOf(intage);
                currentage.setText(age2);
            }
        });

        increaseweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intweight=intweight+1;
                weight2=String.valueOf(intweight);
                currentweight.setText(weight2);
            }
        });

        decreaseage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intage=intage-1;
                age2=String.valueOf(intage);
                currentage.setText(age2);
            }
        });

        decreaseweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intweight=intweight-1;
                weight2=String.valueOf(intweight);
                currentweight.setText(weight2);
            }
        });




        calculatebmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(typeofuser.equals("0")){
                    Toast.makeText(getApplicationContext(),"Select Your Gender First", Toast.LENGTH_SHORT).show();
                }
                else if(mintprogress.equals("0")){
                    Toast.makeText(getApplicationContext(),"Select Your Height First",Toast.LENGTH_SHORT).show();
                }
                else if(intage==0 || intage<0){
                    Toast.makeText(getApplicationContext(),"Age can't be negative",Toast.LENGTH_SHORT).show();
                }
                else if(intweight==0 || intweight<0){
                    Toast.makeText(getApplicationContext(),"Weight can't be negative",Toast.LENGTH_SHORT).show();
                }
                else{
                    SharedPreferences sharedPreferences = getSharedPreferences("Infos",MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("height", mintprogress);
                    editor.putString("gender",typeofuser);
                    editor.putString("weight",weight2);
                    editor.putString("age",age2);
                    editor.apply();


                    Intent intent=new Intent(BMIActivity.this, SecondActivity.class);
                    startActivity(intent);
                    finish();
                }



            }
        });
    }
}