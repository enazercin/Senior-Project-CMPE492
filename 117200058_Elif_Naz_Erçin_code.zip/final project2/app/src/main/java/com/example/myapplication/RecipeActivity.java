package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;

public class RecipeActivity extends AppCompatActivity {

    RecyclerView myRV;
    RecyclerViewAdapter myAdapter;

    List<Recipes> recipes1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        recipes1 = new ArrayList<>();
        recipes1.add(new Recipes("Chicken Marshala","Four 4-ounce boneless, skinless chicken breast cutlets" +
                "Kosher salt and freshly ground black pepper" +
                "1/3 cup whole wheat flour" +
                "1 1/2 tablespoons extra-virgin olive oil" +
                "3/4 cup low-sodium chicken broth" +
                "1/3 cup sun-dried tomatoes (not packed in oil; not rehydrated), finely chopped or very thinly sliced" +
                "1/2 teaspoon finely chopped rosemary" +
                "10 ounces white button or cremini (baby bella) mushrooms, sliced" +
                "1/3 cup sweet marsala wine" +
                "2 teaspoons unsalted butter" +
                "1 to 2 tablespoons roughly chopped flat-leaf parsley","Method","Place the chicken cutlets between 2 pieces of plastic wrap and pound with a meat mallet (or the flat side of a chef's knife) until about 1/3-inch thick. Sprinkle with 1/4 teaspoon salt and 1/4 teaspoon pepper.Put the flour on a medium plate. Heat the oil in a large nonstick skillet over medium-high heat. Dredge the chicken in the flour to fully coat, shaking off any excess. Add the chicken to the skillet and fry until fully cooked and golden brown, about 4 minutes per side. Transfer to a platter and tent with foil to keep warm.Add 1/2 cup of the broth, the sun-dried tomatoes and rosemary to any remaining drippings in the skillet and cook, stirring frequently, for 1 minute to plump the tomatoes. Add the mushrooms, 1/4 teaspoon salt and 1/2 teaspoon pepper and cook until the mushrooms are soft, about 5 minutes. Add the marsala and bring to a boil. Add the remaining 1/4 cup broth and the butter and simmer until the butter is fully melted, about 30 seconds.Spoon the mushroom mixture and sauce over the chicken, sprinkle with the parsley and serve.",R.drawable.chicken)
        );
        recipes1.add(new Recipes("Mixed Berries and Banana Smoothie","1 cup frozen mixed berries" +
                "3/4 cup orange juice" +
                "1/4 cup low-fat vanilla yogurt" +
                "1 frozen ripe banana" +
                "1 teaspoon honey, optional","Method","For the smoothie: Combine the berries, orange juice, yogurt, banana and honey, if using, in a blender and puree until smooth.For the toppings: Pour the smoothie into a bowl. Top with the blueberries, raspberries, vanilla yogurt and granola. Sprinkle with the chia seeds.",R.drawable.smootie)
        );
        recipes1.add(new Recipes("Breakfast Casserole","8 ounces spicy or sweet turkey sausage links, casings removed, meat crumbled" +
                "2 scallions, sliced" +
                "6 large eggs and 6 large egg whites " +
                "1 3/4 cups 1-percent milk" +
                "Kosher salt and freshly ground black pepper" +
                "One 9-ounce package frozen chopped spinach, thawed and drained of excess liquid " +
                "3/4 cup shredded Cheddar" +
                "1/2 cup grated Parmesan" +
                "1/2 whole wheat baguette, cut into 3/4-inch cubes (about 4 cups)" +
                "Cooking spray","Method","Heat a large nonstick skillet over medium heat. Add the turkey and scallions and cook, stirring to break up any large chunks, until browned and cooked through, about 10 minutes. Remove from heat and let cool slightly.Whisk the eggs, egg whites, milk and 1/2 teaspoon each salt and pepper in a large bowl until combined. Add the cooked sausage, spinach, cheeses and bread and toss to distribute the ingredients evenly.Spray a 3-quart casserole dish with cooking spray. Spread the egg mixture evenly in the dish. Cover and refrigerate for at least 6 hours or preferably overnight.Preheat the oven to 350 degrees F. Bake the casserole, uncovered, until set and lightly browned on top, about 30 minutes.",R.drawable.casserole)
        );

        myRV = (RecyclerView)findViewById(R.id.recyclerView_id);

        myAdapter = new RecyclerViewAdapter(this,recipes1);

        myRV.setLayoutManager(new GridLayoutManager(this,1));

        myRV.setAdapter(myAdapter);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setSelectedItemId(R.id.bottom_recipes);

        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()){
                case R.id.bottom_home:
                    startActivity(new Intent(getApplicationContext(), SecondActivity.class));
                    finish();
                    return true;
                case R.id.bottom_tracker:
                    startActivity(new Intent(getApplicationContext(), TrackerActivity.class));
                    finish();
                    return true;
                case R.id.bottom_exercise:
                    startActivity(new Intent(getApplicationContext(), ExerciseActivity.class));
                    finish();
                    return true;
                case R.id.bottom_recipes:
                    return true;
            }
            return false;
        });


    }
}