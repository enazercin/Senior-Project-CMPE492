package com.example.myapplication;

public interface Callback {
    void onSuccess(NutritonData nutritonData);
    void onError(Exception e);
}
