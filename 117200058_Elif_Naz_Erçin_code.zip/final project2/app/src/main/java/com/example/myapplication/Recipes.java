package com.example.myapplication;

public class Recipes {

    private String RecipeName;
    private String RecipeIngredients;
    private String RecipeMethodTitle;
    private String Recipe;
    private int Tumbnail;

    public Recipes(String name, String recipeIngredients, String recipeMethodTitle, String recipe,int tumbnail){

        RecipeName = name;
        RecipeIngredients = recipeIngredients;
        RecipeMethodTitle = recipeMethodTitle;
        Recipe = recipe;
        Tumbnail = tumbnail;

    }

    public String getRecipeName() {
        return RecipeName;
    }

    public String getRecipeIngredients() {
        return RecipeIngredients;
    }

    public String getRecipeMethodTitle() {
        return RecipeMethodTitle;
    }


    public String getRecipe() {
        return Recipe;
    }

    public int getTumbnail() {
        return Tumbnail;
    }
}
