package com.example.myapplication;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ApiIntegrationUtil {

    private static final String API_KEY = "yFhqv7WLMoXJG4f9AOT6tA==qpu4r9hjAL5uhfPB";
    private static final String API_URL = "https://api.api-ninjas.com/v1/nutrition";

    public interface ApiCallback{
        void onResult(NutritonData nutritonData);
        void onError(Exception e);
    }

    public static void queryNutrition(String query, ApiCallback callback) {
        String urlString = API_URL + "?query=" + query;
        new ApiRequestTask(callback).execute(urlString);
    }

    private static class ApiRequestTask extends AsyncTask<String, Void, String> {
        private ApiCallback callback;

        public ApiRequestTask(ApiCallback callback) {
            this.callback = callback;
        }

        @Override
        protected String doInBackground(String... urls) {
            String response = "";
            HttpURLConnection connection = null;
            try {
                URL url = new URL(urls[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("X-Api-Key", API_KEY);

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        stringBuilder.append(line);
                    }
                    reader.close();
                    response = stringBuilder.toString();
                } else {
                    Log.e("ApiIntegrationUtil","Error" + responseCode + "" + connection.getResponseMessage());
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return response;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONArray jsonArray=new JSONArray(result);
                JSONObject jsonObject = jsonArray.getJSONObject(0);
                String itemName = jsonObject.getString("name");
                double calories = jsonObject.getDouble("calories");
                double proteins = jsonObject.getDouble("protein_g");
                double fats = jsonObject.getDouble("fat_total_g");
                double carbs = jsonObject.getDouble("carbohydrates_total_g");

                NutritonData nutritonData = new NutritonData(itemName, calories, proteins, fats, carbs);
                callback.onResult(nutritonData);

            }catch (JSONException e){
                callback.onError(e);

            }

        }
    }
}

